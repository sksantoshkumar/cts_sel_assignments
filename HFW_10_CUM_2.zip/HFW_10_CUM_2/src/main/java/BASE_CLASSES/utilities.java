package BASE_CLASSES;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class utilities {
	
	static int counter=1;
	protected WebDriver dr;
	Logger log;
	
	/*public utilities(WebDriver dr)
	{
		this.dr=dr;
		log = Logger.getLogger("devpinoyLogger");
	}*/
	
	/*public void update_log(String msg)
	{
		log.debug(msg);
	}*/
	
	public WebDriver launch_browser(String browser, String url)
	{
		
		String ch_driver_path="src\\test\\resources\\DRIVER\\chromedriver_v80.exe";
		if(browser.contains("chrome"))
		{
			System.setProperty("webdriver.chrome.driver",ch_driver_path);
			dr = new ChromeDriver();
		}
		else if(browser.contains("firefox"))
		{
			System.setProperty("webdriver.gecko.driver","geckodriver_v0.26.exe");	
			dr = new FirefoxDriver();
		}
		
		dr.get(url);
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		return dr;
	}

	
	
	public void getScreenShot()
	{
		String path = "C:\\Users\\Admin\\Desktop\\EXTRA\\screenshots\\";
		String filename=counter + ".png";
		
		File f1 = ((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
		File f2 = new File(path+filename);
	
		try {
			FileUtils.copyFile(f1, f2);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//this.update_log("IOException occured while taking screenshot");
			System.out.println("screen shot no. : " + counter + " failed");
			e.printStackTrace();
		}
		counter++;
		
	}
	
	public WebElement waitForElement(By locator, int timeout){
		try{
			WebDriverWait wait = new WebDriverWait(dr, timeout);
			WebElement element  = wait.until(
					ExpectedConditions.visibilityOfElementLocated(locator)
					);
			
			System.out.println("Element Located");
			
			return element;
		}catch(Exception e ){
			//this.update_log("Exception occured in waitForElement method");
			System.out.println("Element Not Located " + e);
		}
		return null;
	}
	
	

	public WebElement elementToBeClickable(By locator, int timeout){
		try{
			WebDriverWait wait = new WebDriverWait(dr, timeout);
			WebElement element  = wait.until(
					ExpectedConditions.elementToBeClickable(locator)
					);
			System.out.println("Element Located");
			
			return element;
		}catch(Exception e ){
			//this.update_log("Exception occured in elementToBeClickable method");
			System.out.println("Element Not Located " + e);
		}
		return null;
	}

}
