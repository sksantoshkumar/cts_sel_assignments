package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AUT_home_page {

	WebDriver dr;
	
	By profile_xp = By.xpath("//div[@class='header-links']//child::li[1]/a");
	 
	
	public AUT_home_page(WebDriver dr)
	{
		this.dr = dr;
	}
	
	public String get_actual_eid()
	{
		return dr.findElement(profile_xp).getText();
	}
	
	public void quit()
	{
		dr.close();
	}
}