package STEP_DEF;

import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

import BASE_CLASSES.utilities;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.AUT_home_page;
import pages.AUT_login_page;

public class AUT_step_def_1 {
	
	WebDriver dr;
	AUT_login_page loginpage;
	AUT_home_page homepage;
	
	String url = "http://demowebshop.tricentis.com/login", 
		   uid="trainingservices06@gmail.com",
		   pwd="password",
		   exp_eid="trainingservices06@gmail.com";
		   
	
	utilities util = new utilities();
	
	@Given("^Browser is launched & login page displayed$")
	public void browser_is_launched_login_page_displayed() throws Throwable {
		dr = util.launch_browser("chrome",url);
		loginpage = new AUT_login_page(dr);
		homepage = new AUT_home_page(dr);
	}

	@When("^User enters login credentials & clicks on login$")
	public void user_enters_login_credentials_clicks_on_login() throws Throwable {
		loginpage.do_login(uid, pwd);
	}

	@Then("^Successful login happens & profile name displayed correctly$")
	public void successful_login_happens_profile_name_displayed_correctly() throws Throwable {
		String a_eid = homepage.get_actual_eid();
		SoftAssert sa = new SoftAssert();
		sa.assertEquals(a_eid, exp_eid);
		System.out.println("Actual Eid : " + a_eid);
		homepage.quit();
		sa.assertAll();
	}
}